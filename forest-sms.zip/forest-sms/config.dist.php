<?php

/*
 * Auth Key
 *
 */
define('AUTH_KEY', 'your-auth-key-here');


/*
 * Server Url
 *
 */
define('SERVER', 'https://forestechteam.com/sms/admin/index.php?auth_key='.AUTH_KEY.'&route=api');